import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProductParser extends Parser<Product> {
    
    ProductParser() {
        parsedOutput = new ArrayList<>();
        bracketStack = new Stack<>();
    }

    void printProducts() {
        for (Product p: parsedOutput) {
            System.out.println(p);
        }
    }

    void parse(String filepath) {
        try {
            FileReader file = new FileReader(filepath);
            BufferedReader _buff = new BufferedReader(file);

            StringTokenizer lineTokens;
            String token;
            String line = " ";

            int lineNum = 0;

            boolean[] hasElements = new boolean[3];
            String[] elems = new String[3];

            elems[0] = "CODE";
            elems[1] = "CARRIER_AFM";
            elems[2] = "DESCR";

            while(line != null && !line.trim().toUpperCase().equals("ITEM_LIST")){
                ++lineNum;
                line = _buff.readLine();
            }

            // ++lineNum;

            bracketStack.push(true);

            while(line != null && !bracketStack.isEmpty()) {
                ++lineNum;
                line = _buff.readLine();
                if(line == null)
                    break;

                if(line.trim().equals("}"))
                    bracketStack.pop();

                if(line.trim().toUpperCase().equals("ITEM")){
                    line = _buff.readLine();
                    Product p = new Product();

                    if(line.trim().equals("{")){
                        _buff.mark(2077);

                        boolean angleClosed = false;
                        hasElements[0] = hasElements[1] = hasElements[2] = false;
                        int tempLineNum = 1;

                        bracketStack.push(true);
                        
                        while(!line.trim().toUpperCase().equals("ITEM") && !angleClosed){
                            line = _buff.readLine();

                            angleClosed = line.trim().equals("}");
                            ++tempLineNum;
                            
                            if(line != null && line.isBlank())
                                continue;
                            lineTokens = new StringTokenizer(line);
                            if(lineTokens.countTokens() < 2)
                                continue;

                            token = lineTokens.nextToken();
                            if(token.trim().toUpperCase().equals("CODE")){
                                p.setCode(Integer.parseInt(lineTokens.nextToken()));
                                hasElements[0] = true;
                            }

                            else if(token.trim().toUpperCase().equals("CARRIER_AFM")){
                                p.setProductVAT(lineTokens.nextToken());
                                hasElements[1] = true;
                            }
                            else if(token.trim().toUpperCase().equals("DESCR")){
                                lineTokens.nextToken("\"");
                                p.setDescription(lineTokens.nextToken("\""));
                                hasElements[2] = true;
                            }
                        }
                        
                        if(hasElements[0] && hasElements[1] && hasElements[2] && angleClosed)
                            parsedOutput.add(p);
                        else if(!angleClosed){
                            System.out.println("ITEM in line " + lineNum + " expected closing bracket '}'");
                            tempLineNum = 1;
                            _buff.reset();
                        }
                        else{
                            System.out.println("The following elements are missing from ITEM in line " + lineNum + ":");
                            for(int i = 0; i < 3; ++i)
                                if(!hasElements[i])
                                    System.out.println(elems[i]);
                            System.out.println();
                        }
                        lineNum += tempLineNum;

                        if(angleClosed)
                            bracketStack.pop();
                    }
                    else{
                        System.out.println("Expected { below ITEM in line " + lineNum++);
                    }
                }
            }
            _buff.close();
        } 
        catch(IOException ex) {
            Logger.getLogger(CarrierParser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
